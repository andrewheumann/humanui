Helix Toolkit is a 3D toolkit for .NET

[![Build status](https://ci.appveyor.com/api/projects/status/tmqafdk9p7o98gw7)](https://ci.appveyor.com/project/objorke/helix-toolkit)

[![Pull request status](http://www.issuestats.com/github/helix-toolkit/helix-toolkit/badge/pr?style=flat)](http://www.issuestats.com/github/helix-toolkit/helix-toolkit/)

[![Issues closed status](http://www.issuestats.com/github/helix-toolkit/helix-toolkit/badge/issue?style=flat)](http://www.issuestats.com/github/helix-toolkit/helix-toolkit/)

[![Gitter](https://badges.gitter.im/Join Chat.svg)](https://gitter.im/helix-toolkit/helix-toolkit?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)

Description         | Value
--------------------|-----------------------
License             | The MIT License (MIT)
Web page            | http://helix-toolkit.github.io/
Source repository   | http://github.com/helix-toolkit/helix-toolkit
Latest build        | http://ci.appveyor.com/project/objorke/helix-toolkit
Forum               | http://helixtoolkit.userecho.com/
Issue tracker       | http://github.com/helix-toolkit/helix-toolkit/issues
NuGet packages      | http://www.nuget.org/packages?q=HelixToolkit
StackOverflow       | http://stackoverflow.com/questions/tagged/helix-3d-toolkit
Twitter             | https://twitter.com/hashtag/Helix3DToolkit
Gitter chat         | https://gitter.im/helix-toolkit/helix-toolkit
